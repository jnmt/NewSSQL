package supersql.codegenerator.X3D;

public class X3DValue {

	Double x_ini = 0.0;
	Double y_ini = 0.50;
	Double z_ini = 0.0;
	
	int book_num = 4;
	
	Double x = 6.0;
	Double y = 1.50;	
	Double z = -7.0;
	
	Double book_width = 0.90;
}
