package supersql.codegenerator;

import java.io.Serializable;


public abstract class LocalEnv implements Serializable {
	
	//tk start/////////////////////////////////////////////////
	public static  DecorateList cssclass = new DecorateList();
	public LocalEnv() {

	}
}
