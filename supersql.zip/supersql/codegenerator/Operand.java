package supersql.codegenerator;

public abstract class Operand extends TFE implements IOperand {

	public Operand() {
		super();
	}
}
