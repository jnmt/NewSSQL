package supersql.codegenerator.Compiler.PHP;

public class PHP {

	public static boolean isPHP = false;
	
	public PHP() {

	}
	
}
