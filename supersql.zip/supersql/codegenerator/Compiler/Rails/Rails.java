package supersql.codegenerator.Compiler.Rails;

public class Rails {
	
	public static boolean isRails = false;

	public Rails() {

	}

}
