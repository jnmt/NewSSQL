package supersql.codegenerator.Compiler.JSP;

public class JSP {

	public static boolean isJSP = false;

	
	public JSP() {

	}

}
