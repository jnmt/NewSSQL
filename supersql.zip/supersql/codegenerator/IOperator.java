package supersql.codegenerator;

public abstract interface IOperator extends ITFE {

}
