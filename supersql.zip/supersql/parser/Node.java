package supersql.parser;

import java.util.ArrayList;
import java.util.List;

import org.antlr.v4.runtime.tree.ParseTree;


public class Node {
	public boolean terminal = false;
	public String node = null;
	public String id = null;
}
